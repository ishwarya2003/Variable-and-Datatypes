#!/usr/bin/env python
# coding: utf-8

# # Assignment Instructions
# 
# `Hello Innominion,`
# 
# - **Try to attempt all the questions in every possible way.**
# - **Some other topics are required to solve some questions. don't panic.**
# - **Those questions can be answered after the topics are taught.**
# 
# 
# - `Join Mentoring Session for the Support/Doubts Resolving with Our Technical Mentors (2.00 PM - 6.00 PM  Mon-Sat)` 
# 
# Happy Learning !!!

# ## Basics of Python

# > `Question:` Print your name

# In[2]:


name="My name is Ishwarya"
print(name)


# In[1]:


# CODE HERE


# In[ ]:





# > `Question:` What is a variable? Write a Few words about Variables. Create a Variable with an Example. 

# In[4]:


# WRITE HERE
A python variable is a symbolic name that is a reference or pointer to an object.


# In[14]:


# Code Here

var="ishwarya"
print(var)


# >`Question:` Assume that we execute the following assignment statements:
# width = 17
# height = 12.0
# delimiter = '.'
# For each of the following expressions, write the value of the expression and the type (of the value of
# the expression).
# 1. width/2
# 2. width/2.0
# 3. height/3
# 4. 1 + 2 * 5
# 5. delimiter * 5

# In[13]:


# CODE HERE
width=17
height=12.0
t=1+2*5
delimeter='-'
print(width/2,type(17/2))
print(width/2.0,type(2.0))
print(height/3,type(12.0))
print(t,type(t))
print(delimeter*5,type(delimeter))

# Sample Outputs
1. width/2 = 8.5
2. width/2.0 = 8.5
3. height/3 = 4.0
4. 11
5. .....
# > `Question:` Add two number by taking variable names as first and seccond

# In[12]:


#CODE HERE
print ("first number is:100")
print("second number is:200")
print(first+second)


# In[6]:





# > `Question:` Add your first name and second name

# In[21]:


# CODE HERE
name="ishwarya"
surname="Nampelli"
print("my first name is:ishwarya")
print("My second name is:Nampelli")
print("my full name is:ishwarya Nampelli")


# In[8]:





# In[ ]:





# > `Question:` print the datatypes of the following
# - 10,'10',True,10.5

# In[22]:


# CODE HERE
num1 = 10
num2 = '10'
num3 = True
num4 = 10.5
print(num1, type(num1))
print(num2, type(num2))
print(num3, type(num3))
print(num4, type(num4))


# In[11]:





# # `Question:` 
# > - num_int = 123
# > - num_str = "456"
# > - Add num_int and num_str
# - `hint: first need to convert num_str into integer`

# In[12]:


# CODE HERE 
num_int = 123
num_str =int("456")
print(f'addition of{num_int}and{num_str}is{num_int+num_str}')


# In[ ]:





# In[ ]:





# ### Advanced Questions

# > `Question:` The volume of a sphere with radius r is  4/3πr3  . What is the volume of a sphere with radius 5?

# In[1]:


# CODE HERE
radius=4/3*3.14*5**3
radius


# > `Question:` Suppose the cover price of a book is Rs.24.95, but bookstores get a 40% discount. Shipping costs Rs.3 for the first copy and 75 paise for each additional copy. What is the total wholesale cost for 60 copies?

# In[1]:


# CODE HERE

book=24.95
discount=24.95*40/100
shipping=3
firstprice=book-discount
firstcopy=firstprice+shipping
rem_books=59*0.75
rem_copies=firstprice*59
total_price=rem_copies+firstcopy+rem_books
total_price


# In[ ]:





# In[ ]:





# # [Innomatics Research Labs](https:/innomatics.in/)
# [www.innomatics.in](https:/innomatics.in/)
